# mnist_torch

## Description
Pytorch mnist Example running on nsml 

## How To Run
```bash
# run a session with dataset name mnist
$ nsml run -d mnist
# session name will be displayed

# evaluate model
$ nsml submit SESSION_NANE ITERATION

# infer model
$ nsml infer SESSION_NANE ITERATION
```

