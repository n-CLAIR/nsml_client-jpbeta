# vae_gan

## Description

GAN example with CelebA dataset running on NSML.

## How To Run

```bash
# run a session with dataset name CelebA_128
# available options : #FIXME link
$ nsml run -d CelebA_128
```

## Reference
- PyTorch Implementation of [Autoencoding beyond pixels using a learned similarity metric](https://arxiv.org/abs/1512.09300)
- https://oss.navercorp.com/CLAIR/VAE-GAN-pytorch.git
- https://gist.github.com/gyglim/1f8dfb1b5c82627ae3efcfbbadb9f514
