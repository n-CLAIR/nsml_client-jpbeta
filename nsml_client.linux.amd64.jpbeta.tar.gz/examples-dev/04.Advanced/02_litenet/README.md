# LiteNet

## Description


## How To Run

```bash
# run a session with cohn_kanade dataset
# available option : FIXME link
$ nsml run -d cohn_kanade -e main_category1.py -a "--litenet --layer_config 6 6 6 --use_dtcwt --in_c 18"
```

## Reference
- https://oss.navercorp.com/CLAIR/LiteNet
- https://www.overleaf.com/read/bcjrkwchdcmt
- http://ufldl.stanford.edu/housenumbers/
