import torch
import torch.nn as nn
import dtcwt
import numpy as np

class ComplexWavelet:
  def __init__(self, num_passes=3):
    self.wavelet_transform = dtcwt.numpy.Transform2d()
    self.num_passes = num_passes

  def __call__(self, image):
    image = [self.wavelet_transform.forward(channel, self.num_passes) for channel in image.numpy()]
    image = [pyramid.highpasses[self.num_passes - 1] for pyramid in image]
    image = np.concatenate(image, axis=-1).transpose((2, 0, 1))
    return torch.from_numpy(np.absolute(image))


class DummyNet(nn.Module):
  def __init__(self):
    super(DummyNet, self).__init__()
    self.model = nn.Sequential()
    self.identity = nn.Linear(1,1)

  def forward(self, x):
    return self.model(x)

