"""
Handles creating validation splits for HDF5 datasets.
- Kenta Iwasaki
"""

import h5py
import numpy as np
from PIL import Image


class HDF5Matrix(object):
    def __init__(self, data, labels, index=None, start=0, end=None, transform=None):
        # import pdb; pdb.set_trace()
        self.data = data
        self.labels = labels
        self.start = start
        if end is None:
            self.end = self.data.shape[0]
        else:
            self.end = end
        self.transform = transform
        if index is not None:
            self.index = index
        else:  # full array
            self.index = np.arange(0, len(self), 1)
        """
        import pdb; pdb.set_trace()
        self.mean= np.mean(self.data, axis=(0, 1, 2))
        self.std = np.mean(self.data, axis=(0, 1, 2))
        print(self.mean)
        print(self.std)
        """

        # time consuming
        assert np.any(self.data)
        # assert np.any(self.labels)

        # def get_mean_std(self):

    # return self.mean, self.std

    def __len__(self):
        return self.end - self.start

    def __getitem__(self, key):
        if isinstance(key, slice):
            if key.stop + self.start <= self.end:
                idx = slice(key.start + self.start, key.stop + self.start)
            else:
                raise IndexError
        elif isinstance(key, int):
            idx = self.index[key]
            """
            if key + self.start < self.end:
                idx = key + self.start
            else:
                raise IndexError
            """
        elif isinstance(key, np.ndarray):
            if np.max(key) + self.start < self.end:
                idx = (self.start + key).tolist()
            else:
                raise IndexError
        elif isinstance(key, list):
            if max(key) + self.start < self.end:
                idx = [x + self.start for x in key]
            else:
                raise IndexError
        else:
            raise IndexError

        imgdata = np.uint8(self.data[idx] * 255)
        if imgdata.ndim == 2:
            imgdata = np.repeat(imgdata[:, :, np.newaxis], 3, axis=2)
        imgdata = Image.fromarray(imgdata)
        if self.transform is not None:
            imgdata = self.transform(imgdata)
        if self.labels is not None:
            return imgdata.squeeze(0), np.argmax(self.labels[idx])
        else:
            return imgdata.squeeze(0)

    @property
    def shape(self):
        return (self.end - self.start,) + self.data.shape[1:]


class HDF5Dataset(object):
    def __init__(self, datapath, train_dataset, label_dataset,
                 transform_trn=None, transform_val=None, k_fold=5, k=0):
        self.file = h5py.File(datapath)

        train_dataset = self.file[train_dataset]
        if not k_fold:  # for evaluation
            self.train_data = None
            self.validation_data = HDF5Matrix(train_dataset, None,  transform=transform_val)

        else:
            label_dataset = self.file[label_dataset]

            dataset_length = min(len(label_dataset), len(train_dataset)) \
                if not 'filtered_length' in train_dataset.attrs else \
                train_dataset.attrs['filtered_length']

            self.classes = label_dataset.attrs['classes'].split(',')

            # get k-fold split indicesfr
            from sklearn.model_selection import KFold
            kf = KFold(n_splits=k_fold, random_state=None, shuffle=False)
            for idx, (train_idx, test_idx) in enumerate(kf.split(train_dataset)):
                if idx == k:
                    self.train_data = HDF5Matrix(train_dataset, label_dataset,
                                                 index=train_idx, start=0, end=len(train_idx),
                                                 transform=transform_trn)
                    self.validation_data = HDF5Matrix(train_dataset, label_dataset,
                                                      index=test_idx, start=0, end=len(test_idx),
                                                      transform=transform_val)
                    break  # no need to run rest

            print('datapath: %s' % datapath)
            print('%d st split for %d-fold cv' % (k, k_fold))
            print('# of train samples: %d(%f)' % (len(train_idx), len(train_idx) * 1.0 / dataset_length))
            print('# of valid samples: %d(%f)' % (len(test_idx), len(test_idx) * 1.0 / dataset_length))
