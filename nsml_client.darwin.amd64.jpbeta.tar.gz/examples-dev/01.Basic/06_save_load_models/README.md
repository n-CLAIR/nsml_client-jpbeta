## Description
Example of `nsml.load_folder()` and `nsml.save_folder()` 

## How To Run
```bash
# run a tensorflow example 
$ nsml run -e tensorflow_save.py

# run a pytorch example 
$ nsml run -e torch_save.py
```

If you want to test `nsml.load_folder()`, You need to replace the `session_name` variable in each file with the appropriate name. 