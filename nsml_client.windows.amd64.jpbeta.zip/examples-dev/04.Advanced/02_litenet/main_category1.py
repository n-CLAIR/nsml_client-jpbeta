import os
import argparse
import base64
from io import BytesIO
import time
from PIL import Image
import torch
from torch import optim
from torch.nn.functional import softmax
from models.DTCWT import *
import models.LiteNetV2 as lnetv2
import models.LiteNet as lnet
import models.DenseNet161FE28 as dnetFE28
import models.ResNet101FE28 as rnet
from misc.misc import *
import nsml
from nsml import HAS_DATASET, DATASET_PATH, DATASET_NAME
from libs.hdf5_pytorch import HDF5Dataset


torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True

TEST_STR = ['test', 'evaluate', 'predict']
INFER_STR = ['inference', 'infer']

# emotion index (only for cohn_kanade)
EMOTION = ['Angry', 'Contempt', 'Disgust', 'Fear', 'Happy', 'Sadness', 'Surprise']


def bind_model(FE, FC, data_info=dict(), optimizer=None):
    def load(dir_name, *args):
        state = torch.load(os.path.join(dir_name, 'model.pth'))
        FE.load_state_dict(state['FE'])
        FC.load_state_dict(state['FC'])
        if optimizer and 'optimizer' in state:
            optimizer.load_state_dict(state['optimizer'])
        if 'data_transform' in state:
            data_info['data_transform'] = state['data_transform']
        if 'classes' in state:
            data_info['classes'] = state['classes']
        print("Model loaded")

    def save(dir_name, *args):
        state = {
            'FE': FE.state_dict(),
            'FC': FC.state_dict(),
            'optimizer': optimizer.state_dict(),
            'data_transform': data_info['data_transform'],
            'classes': data_info['classes']
        }
        torch.save(state, os.path.join(dir_name, 'model.pth'))

    def infer(input, top_k=100):
        FE.eval()
        FC.eval()
        full_prediction = list()
        if 'classes' in data_info:
            emotion = data_info['classes']
        else:
            emotion = EMOTION
        for image in input:
            input_var = torch.autograd.Variable(image.cuda(async=True), volatile=True)
            feature = FE(input_var)
            logit = FC(feature.detach())
            batch_size, all_cls = logit.size()
            pred = softmax(logit).topk(min(top_k, all_cls))
            for idx in range(batch_size):
                one_row = list(zip(list(pred[0][idx].data),
                                   [emotion[e_idx] for e_idx in list(pred[1][idx].data)]))
                full_prediction.append(one_row)
        return full_prediction

    def evaluate(test_data, output):
        # FIXME: cohn-kanade only
        dataset = HDF5Dataset(os.path.join(DATASET_PATH, test_data, '{}.h5'.format(DATASET_NAME)),
                              'greyscale', 'labels',
                              transform_trn=None, transform_val=data_info['data_transform'],
                              k_fold=0, k=0)
        print('load data')
        dataset_val = torch.utils.data.DataLoader(dataset.validation_data,
                                                  batch_size=1,
                                                  shuffle=False,
                                                  num_workers=4)
        print('dataloader')
        full_pred = nsml.infer(input=dataset_val, decode_fn='skip', top_k=1)
        # Stringify
        result = [str(pred[0][1]) for pred in full_pred]
        with open(output, 'w') as file_writer:
            file_writer.write("\n".join(result))

    # for web-application
    def decode(str_base64):
        # from image string to image
        binary_str = base64.b64decode(str_base64.split('base64,')[1])
        # load image
        image = Image.open(BytesIO(binary_str))
        # hack
        image = image.convert('L')
        if image.mode == 'L':  # if image if greyscale
            import numpy as np
            image_array = np.asarray(image)
            image_array = np.repeat(image_array[:, :, np.newaxis], 3, axis=2)
            image = Image.fromarray(image_array)
        elif image.mode != 'RGB':
            image = image.convert('RGB')
        # from image to tensor
        data = torch.utils.data.DataLoader([data_info['data_transform'](image)],
                                           batch_size=1,
                                           shuffle=False,
                                           num_workers=4)
        return data

    nsml.bind(save, load, infer)


def train(train_loader, modelFE, modelFC, criterion, optimizerFC, epoch,
          global_iter, scope, total_epoch, display=100):
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()

    modelFE.eval()
    modelFC.train()

    end = time.time()
    for i, (input, target) in enumerate(train_loader, 0):
        data_time.update(time.time() - end)

        target = torch.LongTensor(target.size(0)).copy_(target).cuda(async=True)
        target_var = torch.autograd.Variable(target)
        input_var = torch.autograd.Variable(input.cuda(async=True))

        feature = modelFE(input_var)
        logit = modelFC(feature.detach())
        loss = criterion(logit, target_var)

        prec1, prec5, _, _ = accuracy(logit.data, target, topk=(1, 5))
        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

        optimizerFC.zero_grad()
        loss.backward()
        optimizerFC.step()
        global_iter += 1

        batch_time.update(time.time() - end)
        end = time.time()

        current_lr = optimizer.param_groups[0]['lr']
        
        nsml.report(
            epoch=epoch,
            epoch_total=total_epoch,
            iter=i,
            iter_total=len(train_loader),
            perf__batch_time=batch_time.val,
            perf__data_time=data_time.val,
            train__loss=losses.val, 
            train__top1=top1.val, 
            train__top5=top5.val,
            misc__lr=current_lr,                
            scope=dict(scope,**locals())
        )
        
        if i % display == 0:
            print('Epoch: [{0}][{1}/{2}] [{3}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                  'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'
                  'lr: {lr:f}'.format(
                epoch, i, len(train_loader), global_iter,
                batch_time=batch_time,
                data_time=data_time,
                loss=losses, top1=top1, top5=top5,
                lr=current_lr))
            sys.stdout.flush()

            trainLogger.write('%d\t%f\t%f\n' % (global_iter, losses.val, top1.val))
            trainLogger.flush()
    return global_iter


def validate(val_loader, modelFE, modelFC, criterion,
             global_iter, epoch, scope, total_epoch=None, prediction='./pred_res.txt'):
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    incorrect = 0
    test_loss = 0

    modelFE.eval()
    modelFC.eval()

    pred_list = list()

    for i, (input, target) in enumerate(val_loader, 1):
        target = torch.LongTensor(target.size(0)).copy_(target).cuda(async=True)
        target_var = torch.autograd.Variable(target, volatile=True)
        input_var = torch.autograd.Variable(input.cuda(async=True), volatile=True)

        feature = modelFE(input_var)
        logit = modelFC(feature.detach())
        loss = criterion(logit, target_var)

        test_loss += loss.data[0]
        pred = logit.data.max(1)[1]
        incorrect += pred.ne(target_var.data).cpu().sum()
        prec1, prec5, _, _ = accuracy(logit.data, target, topk=(1, 5))

        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

        pred_list.append(str(pred.cpu().numpy()[0][0]))

    test_loss /= len(val_loader)
    nTotal = len(val_loader.dataset)
    err = 100. * incorrect / nTotal
    with open(prediction, 'w') as fp:
        fp.write('\n'.join(pred_list))

    print('Test: [{0}/{1}]\t'
          'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
          'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
          'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'.format(i, len(val_loader),
                                                            loss=losses, top1=top1, top5=top5))
    print('\nTest set: Average loss: {:.4f}, Error: {}/{} ({:.2f}%)\n'.format(
        test_loss, incorrect, nTotal, err))
    sys.stdout.flush()

    if epoch >= 0:
        nsml.report(
            summary=True,
            epoch=epoch,
            total_epoch=total_epoch,
            test__loss=test_loss, 
            test__top1=top1.avg,
            test__top5=top5.avg,
            test__err=err,
            scope=dict(scope,**locals())
        )

    valLogger.write('%d\t%f\t%f\t%f\n' % (global_iter, losses.avg, top1.avg, err))
    valLogger.flush()
    return top1.avg


'''def data_loader(root_path, train=True):
    data_name = 'cohn_kanade.h5'
    if train:
        # FIXME: only cohn_kanade
        root_path = os.path.join(root_path, 'train')
        dataset_trn, dataset_val, transform_val, classes = \
            get_loader(os.path.join(root_path, data_name),
                       original_size=opt.original_size,
                       image_size=opt.image_size,
                       batch_size=opt.batch_size,
                       val_batch_size=opt.val_batch_size,
                       workers=opt.workers,
                       k_fold=opt.k_fold, k=opt.k,
                       data_format=opt.data_format,
                       use_dtcwt=opt.use_dtcwt, num_passes=opt.num_passes)
        return dataset_trn, dataset_val, transform_val, classes

    root_path = os.path.join(root_path, 'test')
    dataset = HDF5Dataset(os.path.join(root_path, data_name),
                          'greyscale', 'labels',
                          transform_trn=None, transform_val='',
                          k_fold=0, k=0)
    return {'data': dataset}'''


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='', help='')
    parser.add_argument('--data_format', default='images', help='raw data format in the HDF files [greyscale|images]')
    parser.add_argument('--k_fold', type=int, default=5, help='k-fold C.C.VV')
    parser.add_argument('--k', type=int, default=0, help='k th split for k-fold cv')
    parser.add_argument('--image_size', type=int, default=224, help='')
    parser.add_argument('--original_size', type=int, default=256, help='')
    parser.add_argument('--nclasses', type=int, default=7, help='number of classes')
    parser.add_argument('--litenet', action='store_true', help='whether to use LiteNet or not')
    parser.add_argument('--litenetv2', action='store_true', help='whether to use LiteNetV2 or not')
    parser.add_argument('--use_dtcwt', action='store_true', help='whether to use dtcwt encoder')
    parser.add_argument('--num_passes', type=int, default=3, help='# of levels in dtcwt')
    parser.add_argument('--groups', type=int, default=3, help='# of groups')
    parser.add_argument('--densenetfe', action='store_true',
                        help='whether to use densenet arch. for feature extractor or not')
    parser.add_argument('--resnetfe', action='store_true',
                        help='whether to use densenet arch. for feature extractor or not')
    parser.add_argument('--channel_size', type=int, default=12, help='size of base channel size for each arch.')
    parser.add_argument('--layer_config', nargs='+', type=int)
    parser.add_argument('--in_c', type=int, default=3, help='number of input channel size, (image=3, dtcwt=18)')
    parser.add_argument('--ngpu', type=int, default=1, help='# of gpu-cards for data-parallel training')
    parser.add_argument('--lr', type=float, default=0.001, help='initial learning rate')
    parser.add_argument('--wd', type=float, default=0, help='weight decay(a.k.a. L2 regularizor)')
    parser.add_argument('--batch_size', type=int, default=64, help='train batch size')
    parser.add_argument('--val_batch_size', type=int, default=1, help='validation batch size')
    parser.add_argument('--niter', type=int, default=160, help='number of epochs to train for')
    parser.add_argument('--exp', default='sample', help='folder to output logs and model checkpoints')
    parser.add_argument('--display', type=int, default=5, help='interval for console display')
    parser.add_argument('--workers', type=int, default=4, help='# of processes for dataloader')

    parser.add_argument('--mode', type=str, default='train')
    parser.add_argument('--iteration', type=str, default='0')
    parser.add_argument('--prediction', type=str, default='./pred_res.txt')
    parser.add_argument('--test', type=str, default='')
    parser.add_argument('--pause', type=int, default=0)
    opt = parser.parse_args()

    assert opt.channel_size > 0
    assert opt.groups > 0
    if opt.use_dtcwt:
        assert opt.num_passes > 0

    if opt.use_dtcwt:
        opt.in_c = 18

    if not HAS_DATASET:
        datasetID = opt.dataset.split('/')[-1]
    else:
        datasetID = DATASET_NAME

    if 'radboud' in datasetID:
        opt.nclasses = 8
    if 'radboud' in datasetID or 'cohn_kanade' in datasetID:
        opt.data_format = 'greyscale'

    if opt.densenetfe:
        assert opt.in_c == 384
    if opt.resnetfe:
        assert opt.in_c == 512

    opt.torch_version = torch.__version__

    opt.exp = os.path.join(opt.exp, '%d_in_%d_fold' % (opt.k, opt.k_fold))
    create_exp_dir(opt.exp)
    torch.manual_seed(1)

    if HAS_DATASET:
        # FIXME: only cohn_kanade
        DATASET_PATH = os.path.join(DATASET_PATH, 'train')
        data_name = ['cohn_kanade.h5']
        if len(data_name) != 1:
            raise KeyError
        dataset_trn, dataset_val, transfrom_val, classes =\
            get_loader(os.path.join(DATASET_PATH, data_name[0]),
                       original_size=opt.original_size,
                       image_size=opt.image_size,
                       batch_size=opt.batch_size,
                       val_batch_size=opt.val_batch_size,
                       workers=opt.workers,
                       k_fold=opt.k_fold, k=opt.k,
                       data_format=opt.data_format,
                       use_dtcwt=opt.use_dtcwt, num_passes=opt.num_passes)

    else:
        raise FileNotFoundError()

    if opt.litenetv2:
        FE = DummyNet()
        FC = lnetv2.Net(in_c=opt.in_c, image_size=opt.image_size,
                        growth_rate=opt.channel_size, num_classes=opt.nclasses,
                        layer_config=opt.layer_config, groups=1,
                        ngpu=opt.ngpu)
    elif opt.litenet:
        FE = DummyNet()
        FC = lnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                      growth_rate=opt.channel_size, num_classes=opt.nclasses,
                      layer_config=opt.layer_config, groups=opt.groups,
                      ngpu=opt.ngpu)
    elif opt.densenetfe:
        FE = dnetFE28.Net(pretrained=True)
        FC = lnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                      growth_rate=opt.channel_size, num_classes=opt.nclasses,
                      layer_config=opt.layer_config, groups=opt.groups,
                      ngpu=opt.ngpu)
    elif opt.resnetfe:
        FE = rnet.Net(pretrained=True)
        FC = lnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                      growth_rate=opt.channel_size, num_classes=opt.nclasses,
                      layer_config=opt.layer_config, groups=opt.groups,
                      ngpu=opt.ngpu)
    else:
        assert 0
    criterion = torch.nn.CrossEntropyLoss()
    num_params, size_params = check_model_complexity(FE)
    print('# of params in Feature Extraction model: %d, size of model: %f MB' % \
          (num_params, size_params))
    num_params, size_params = check_model_complexity(FC)
    print('# of params in Classification model: %d, size of model: %f MB' % \
          (num_params, size_params))

    FE.cuda()
    FC.cuda()
    criterion.cuda()

    trainLogger = open('%s/train.log' % opt.exp, 'w')
    valLogger = open('%s/val.log' % opt.exp, 'w')

    optimizer = optim.Adam(FC.parameters(), lr=opt.lr, betas=(0.9, 0.999), weight_decay=0)

    bind_model(FE, FC,
               {'data_transform': transfrom_val, 'classes': classes},
               optimizer)
    best_prec = -1
    best_epoch = -1
    global_iter = 0

    if opt.pause:
        nsml.paused(scope=locals())

    if opt.mode.lower() not in TEST_STR + INFER_STR:
        for epoch in range(1, opt.niter + 1):
            global_iter = train(dataset_trn,
                                FE, FC, criterion, optimizer,
                                epoch, global_iter, display=opt.display, scope=locals(),
                                total_epoch=opt.niter)
            prec = validate(dataset_val,
                            FE, FC, criterion, global_iter, epoch, scope=locals(),
                            total_epoch=opt.niter)
            if prec > best_prec:
                best_prec = prec
                best_epoch = epoch
                nsml.save(epoch)
            # FIXME
            if epoch == opt.niter or epoch % 5 == 0:
                nsml.save(epoch)
        print('Best accuracy: %f in epoch %d' % (best_prec, best_epoch))
    trainLogger.close()
    valLogger.close()
