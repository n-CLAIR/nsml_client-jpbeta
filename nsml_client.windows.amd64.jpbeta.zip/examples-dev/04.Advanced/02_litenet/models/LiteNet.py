import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F

torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True
import torch.nn.parallel
import math

"""
class ShuffleBlock(nn.Module):
  def __init__(self, groups):
    super(ShuffleBlock, self).__init__()
    self.groups = groups

  def forward(self, x):
    if self.groups == 1:
      return x
    '''Channel shuffle: [N,C,H,W] -> [N,g,C/g,H,W] -> [N,C/g,g,H,w] -> [N,C,H,W]'''
    N,C,H,W = x.size()
    g = self.groups
    return x.view(N,g,int(C/g),H,W).permute(0,2,1,3,4).contiguous().view(N,C,H,W)
"""


class TransitionBlock(nn.Module):
    def __init__(self, inc, outc, k_size):
        super(TransitionBlock, self).__init__()
        self.conv1 = nn.Conv2d(inc, outc, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(outc)
        self.relu1 = nn.ReLU(inplace=True)
        self.compression = nn.AvgPool2d(k_size)

    def forward(self, x):
        out = self.relu1(self.bn1(self.conv1(x)))
        out = self.compression(out)
        return out


class BottleneckBlock(nn.Module):
    def __init__(self, inc, outc, stride, groups=1):
        super(BottleneckBlock, self).__init__()
        self.stride = stride
        self.inc = inc
        self.outc = outc
        self.stride = stride

        def conv_separable(inp, oup, stride, groups=1):
            bottleneckC = oup * 4
            return nn.Sequential(
                nn.Conv2d(inp, bottleneckC, 1, 1, 0, groups=groups, bias=False),
                nn.BatchNorm2d(bottleneckC),
                nn.ReLU(inplace=True),

                nn.Conv2d(bottleneckC, bottleneckC, 3, stride, 1, groups=bottleneckC, bias=False),
                nn.BatchNorm2d(bottleneckC),
                nn.ReLU(inplace=True),

                nn.Conv2d(bottleneckC, oup, 1, 1, 0, groups=1, bias=False),
                nn.BatchNorm2d(oup),
                nn.ReLU(inplace=True),
            )

        self.bottleneck = conv_separable(inc, outc, stride, groups)

    def forward(self, x):
        # import pdb; pdb.set_trace()
        out = self.bottleneck(x)
        out = torch.cat([x, out], 1)
        return out


class Net(nn.Module):
    def __init__(self, in_c=18, image_size=224,
                 growth_rate=12, num_classes=1000, layer_config=[1, 5, 1], groups=1, ngpu=1):
        super(Net, self).__init__()
        self.ngpu = ngpu

        inc = 2 * growth_rate
        compression = 0.5
        if image_size == 32 or \
                (image_size == 224 and in_c == 18) or \
                (image_size == 224 and in_c == 512) or \
                (image_size == 224 and in_c == 384):
            conv0 = nn.Conv2d(in_c, inc, kernel_size=3, stride=1, padding=1, bias=False)
        elif image_size == 224 and in_c == 3:
            conv0 = nn.Conv2d(in_c, inc, 7, 2, 3, bias=False)
            maxpool0 = nn.MaxPool2d(3, 2, 1)

        bn0 = nn.BatchNorm2d(inc)
        relu0 = nn.ReLU(inplace=True)
        if image_size == 32 or \
                (image_size == 224 and in_c == 18) or \
                (image_size == 224 and in_c == 512) or \
                (image_size == 224 and in_c == 384):
            body = [conv0, bn0, relu0]
        elif image_size == 224 and in_c == 3:
            body = [conv0, bn0, relu0, maxpool0]

        stage = len(layer_config)
        for ind, con in enumerate(layer_config):
            for repeat in range(con):
                body.append(BottleneckBlock(inc, growth_rate, 1, groups))
                inc += growth_rate
            if ind < len(layer_config) - 1:
                outc = int(math.floor(inc * compression))
                body.append(TransitionBlock(inc, outc, 2))
                inc = outc

        self.model = nn.Sequential(*body)

        self.output_size = inc
        self.fc = nn.Linear(self.output_size, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.bias.data.zero_()

    def forward(self, x):
        if isinstance(x.data, torch.cuda.FloatTensor) and self.ngpu > 1:
            x = nn.parallel.data_parallel(self.model, x, range(self.ngpu))
        else:
            x = self.model(x)
        x = F.avg_pool2d(x, kernel_size=x.size()[2:])
        x = x.view(-1, self.output_size)
        x = self.fc(x)
        return x
