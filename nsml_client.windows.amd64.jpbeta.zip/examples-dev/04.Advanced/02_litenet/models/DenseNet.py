import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True
import math

class TransitionBlock(nn.Module):
  def __init__(self, inc, outc, k_size):
    super(TransitionBlock, self).__init__()
    self.bn1 = nn.BatchNorm2d(inc)
    self.relu1 = nn.ReLU(inplace=True)
    self.conv1 = nn.Conv2d(inc, outc, 1, 1, bias=False)
    self.reduction = nn.AvgPool2d(k_size)

  def forward(self, x):
    out = self.conv1(self.relu1(self.bn1(x)))
    out = self.reduction(out)
    return out


class BottleneckBlock(nn.Module):
  def __init__(self, inc, outc, stride, groups):
    super(BottleneckBlock, self).__init__()

    def block(inp, oup, stride, groups=1):
      internalc = oup * 4 # bottlenked version, i.e. DenseNetB
      return nn.Sequential(
        nn.BatchNorm2d(inp),
        nn.ReLU(inplace=True),
        nn.Conv2d(inp, internalc, 1, 1, 0, groups=groups, bias=False),

        nn.BatchNorm2d(internalc),
        nn.ReLU(inplace=True),
        nn.Conv2d(internalc, oup, 3, stride, 1, groups=1, bias=False),
      )
    self.bottleneck = block(inc, outc, stride, groups)

  def forward(self, x):
    out = self.bottleneck(x)
    out = torch.cat([out,x],1)
    return out
  

class Net(nn.Module):
  def __init__(self, in_c=3, growth_rate=12, num_classes=1000, layer_config=[16, 16, 16], compression=0.5, groups=1, ngpu=1):
    super(Net, self).__init__()
    self.ngpu = ngpu

    inc = 2*growth_rate

    body = []
    if len(layer_config) == 3:
      conv0 = nn.Conv2d(in_c, inc, kernel_size=3, stride=1, padding=1, bias=False)
      body = [conv0]
    elif len(layer_config) > 3:
      conv0 = nn.Conv2d(in_c, inc, 7, 2, 3, bias=False)
      bn0 = nn.BatchNorm2d(inc)
      relu0 = nn.ReLU(inplace=True)
      pool0 = nn.MaxPool2d(3, 2, 1)
      body = [conv0, bn0, relu0, pool0]


    stage = len(layer_config)
    for ind, con in enumerate(layer_config):
      for repeat in range(con):
        body.append(BottleneckBlock(inc, growth_rate, 1, groups))
        inc += growth_rate
      if ind < len(layer_config)-1:
        outc = int(math.floor(inc*compression)) # Compressed version, i.e. DenseNetC
        body.append(TransitionBlock(inc, outc, 2))
        inc = outc
       
    body.append(nn.BatchNorm2d(inc))
    body.append(nn.ReLU(inplace=True))

    self.model = nn.Sequential(*body)

    self.output_size = inc
    self.fc = nn.Linear(self.output_size, num_classes)

    for m in self.modules():
      if isinstance(m, nn.Conv2d):
        n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
        m.weight.data.normal_(0, math.sqrt(2. / n))
      elif isinstance(m, nn.BatchNorm2d):
        m.weight.data.fill_(1)
        m.bias.data.zero_()
      elif isinstance(m, nn.Linear):
        m.bias.data.zero_()


  def forward(self, x):
    if isinstance(x.data, torch.cuda.FloatTensor) and self.ngpu > 1:
      x = nn.parallel.data_parallel(self.model, x, range(self.ngpu))
    else: 
      x = self.model(x)
    x = F.avg_pool2d(x, kernel_size=7)
    #x = F.avg_pool2d(x, kernel_size=x.size()[2:])
    x = x.view(-1, self.output_size)
    x = self.fc(x)
    return x
