""" 05: Hello NSML with Multidata
=====================================

A simple example of how to connect to NSML and print a few values.

"""

import torch
import time
import os
from nsml import GPU_NUM, DATASET_PATH, DATASET_NAME

print('DATASET PATH', DATASET_PATH, 'TYPE', type(DATASET_PATH))
print('DATASET NAME', DATASET_NAME, 'TYPE', type(DATASET_NAME))

with open(os.path.join(DATASET_PATH[0], 'train/data.txt')) as f:
    print('read from dataset {0}'.format(DATASET_NAME[0]), [line for line in f])

# print number of gpus
print('Number of gpus: {}'.format(GPU_NUM))

print('Hello NSML!')
for x in range(20):
    time.sleep(1)
    print('Hello timer', x)
print(torch)
