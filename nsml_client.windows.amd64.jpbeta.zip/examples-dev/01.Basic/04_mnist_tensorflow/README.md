# mnist_tensorflow

## Description
mnist with TensorFlow running on NSML

## How To Run

```bash
# run a session with mnist dataset
# available options : --mode, --batch, --lr, --epochs, --top, --iteration, --pause, --gpu
$ nsml run -d mnist

# evaluate model
$ nsml submit SESSION_NANE ITERATION

# infer model
$ nsml infer SESSION_NANE ITERATION
```
