import argparse
import numpy as np
import os

from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf

import nsml
from nsml import DATASET_PATH, HAS_DATASET
from mnist_reader import read_image_file, read_label_file

"""
def bind_model(sess):
    def save(dir_name):
        # directory
        os.makedirs(dir_name, exist_ok=True)
        saver = tf.train.Saver()
        saver.save(sess, os.path.join(dir_name, 'model'))

    def load(dir_name):
        saver = tf.train.Saver()
        # find checkpoint
        ckpt = tf.train.get_checkpoint_state(dir_name)
        if ckpt and ckpt.model_checkpoint_path:
            checkpoint = os.path.basename(ckpt.model_checkpoint_path)
            saver.restore(sess, os.path.join(dir_name, checkpoint))
        else:
            raise NotImplemented('No checkpoint!')

    def infer(input, top_k=100):
        input = _concatenate_matrix(preprocess(input)['data'])
        pred = sess.run(y, feed_dict={x: input})
        all_cls = len(pred)
        pred = tf.nn.top_k(tf.nn.softmax(pred), k=min(top_k, all_cls))
        pred = tf.Session().run(pred)
        return list(zip(list(pred[0].flatten()), list(pred[1].flatten())))

    nsml.bind(save=save, load=load, infer=infer)
"""


def infer(input, top_k=100):
    input = _concatenate_matrix(np.array(preprocess(input)).astype(float))
    pred = sess.run(y_conv, feed_dict={x: input, keep_prob: 1.0})
    all_cls = len(pred[0])
    pred = tf.nn.top_k(tf.nn.softmax(pred), k=min(top_k, all_cls))
    pred = tf.Session().run(pred)
    return list(zip(list(pred[0].flatten()), list(pred[1].flatten())))


def preprocess(input):
    if 'PIL' in str(type(input[0])):
        for idx in range(len(input)):
            input[idx] = np.asarray(input[idx])
    return input


# supported by dataset owner
def data_loader(root_path):
    root_path = os.path.join(root_path, 'train')
    data_dict = {
        'train': {
            'data': read_image_file(os.path.join(root_path, 'train', 'train-images-idx3-ubyte')),
            'label': read_label_file(os.path.join(root_path, 'train', 'train-labels-idx1-ubyte'))
        },
        'test': {
            'data': read_image_file(os.path.join(root_path, 'test', 't10k-images-idx3-ubyte')),
            'label': read_label_file(os.path.join(root_path, 'test', 't10k-labels-idx1-ubyte'))
        }
    }
    return data_dict


def _concatenate_matrix(x):
    x_vec = np.zeros((x.shape[0], x.shape[1] * x.shape[2]), dtype=np.float)
    for idx, one_line in enumerate(x):
        x_vec[idx] = one_line.flatten()
    return x_vec


def _one_hot_encoder(y):
    y_vec = np.zeros((len(y), 10), dtype=np.float)
    for i, label in enumerate(y):
        y_vec[i, y[i]] = 1.0
    return y_vec


def _batch_loader(iterable, n=1):
    length = len(iterable)
    for n_idx in range(0, length, n):
        yield iterable[n_idx:min(n_idx + n, length)]


def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)


def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)


def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')


if __name__ == '__main__':
    # mode argument
    args = argparse.ArgumentParser()
    args.add_argument("--mode", type=str, default="train")
    args.add_argument("--batch", type=int, default=128)
    args.add_argument("--lr", type=float, default=0.001)
    args.add_argument("--epochs", type=int, default=30)
    args.add_argument("--top", type=int, default=100)
    args.add_argument("--iteration", type=str, default='0')
    args.add_argument("--pause", type=int, default=0)
    args.add_argument("--gpus", type=int, default=1)
    config = args.parse_args()

    # Create the model
    x = tf.placeholder(tf.float32, [None, 784])
    y_ = tf.placeholder(tf.float32, [None, 10])

    x_image = tf.reshape(x, [-1, 28, 28, 1])
    W_conv1 = weight_variable([5, 5, 1, 32])
    b_conv1 = bias_variable([32])

    h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)
    h_pool1 = max_pool_2x2(h_conv1)

    W_conv2 = weight_variable([5, 5, 32, 64])
    b_conv2 = bias_variable([64])

    h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)
    h_pool2 = max_pool_2x2(h_conv2)

    W_fc1 = weight_variable([7 * 7 * 64, 1024])
    b_fc1 = bias_variable([1024])

    h_pool2_flat = tf.reshape(h_pool2, [-1, 7 * 7 * 64])
    h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

    keep_prob = tf.placeholder(tf.float32)
    h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

    W_fc2 = weight_variable([1024, 10])
    b_fc2 = bias_variable([10])

    y_conv = tf.matmul(h_fc1_drop, W_fc2) + b_fc2

    # Define loss and optimizer
    cross_entropy = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits(labels=y_, logits=y_conv))
    train_step = tf.train.AdamOptimizer(config.lr).minimize(cross_entropy)

    # accuracy
    correct_prediction = tf.equal(tf.argmax(y_conv, 1), tf.argmax(y_, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    sess = tf.InteractiveSession()
    nsml.bind(infer=infer, sess=sess)
    if config.pause:
        nsml.paused(scope=locals())

    if config.mode == 'train':
        tf.global_variables_initializer().run()

        if HAS_DATASET:
            data = data_loader(DATASET_PATH)
            x_train = _concatenate_matrix(data['train']['data'])
            y_train = _one_hot_encoder(data['train']['label'])
            x_test = _concatenate_matrix(data['test']['data'])
            y_test = _one_hot_encoder(data['test']['label'])
        else:
            dataset = input_data.read_data_sets('/tmp/tensorflow/mnist/input_data', one_hot=True)
            x_train = dataset.train.images
            x_test = dataset.test.images
            y_train = dataset.train.labels
            y_test = dataset.test.labels
        # Train
        step = 0
        for epoch in range(config.epochs):
            batch_idx = 0
            for iter_idx, (batch_xs, batch_ys) in \
                    enumerate(zip(_batch_loader(x_train, config.batch),
                                  _batch_loader(y_train, config.batch))):
                batch_idx += 1
                _, loss = sess.run([train_step, cross_entropy],
                                      feed_dict={x: batch_xs, y_: batch_ys,
                                                 keep_prob: 0.5})
                train_acc = sess.run(accuracy, feed_dict={x: batch_xs, y_: batch_ys,
                                                 keep_prob: 1.0})
                step += 1
                nsml.report(epoch=epoch, epoch_total=config.epochs,
                            train__loss=float(loss), train__acc=float(train_acc),
                            iter_total=config.batch,
                            iter=batch_idx, scope=locals(), step=step)
            test_loss, test_acc = sess.run([cross_entropy, accuracy],
                                           feed_dict={x: x_test, y_: y_test, keep_prob: 1.0})
            nsml.report(summary=True, epoch=epoch, epoch_total=config.epochs,
                        test__accuracy=float(test_acc), test__loss=float(test_loss),
                        scope=locals())
            nsml.save(epoch)
            print('test_acc: {}, test_loss: {}'.format(test_acc, test_loss))
