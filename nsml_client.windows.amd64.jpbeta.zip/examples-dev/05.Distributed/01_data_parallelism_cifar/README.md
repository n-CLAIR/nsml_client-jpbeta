# distributed_cifar100

## Description

Distributed resnet cifar100

## How To Run
```
# for 2 nodes, each node have 2 gpus
$ nsml run --gpu-driver-version 410.79 -d CIFAR100 -g 2 -n 2 -c 10 --memory 50G --shm-size 10G
```

## Reference

- https://github.com/zhunzhong07/Random-Erasing
- https://github.com/facebook/fb.resnet.torch
- https://github.com/pytorch/vision/blob/master/torchvision/models/resnet.py
